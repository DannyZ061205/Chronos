import { r as reactExports, D as DEFAULT_SETTINGS, a as getDefaults, b as getTimezone, j as jsxRuntimeExports, e as saveDefaults, d as client, R as React } from "./index.js";
function OptionsApp() {
  const [defaults, setDefaults] = reactExports.useState(DEFAULT_SETTINGS);
  const [googleConnected, setGoogleConnected] = reactExports.useState(false);
  const [outlookConnected, setOutlookConnected] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  const [message, setMessage] = reactExports.useState("");
  const [openaiApiKey, setOpenaiApiKey] = reactExports.useState("");
  const [showApiKey, setShowApiKey] = reactExports.useState(false);
  reactExports.useEffect(() => {
    loadSettings();
    checkConnectionStatus();
  }, []);
  const loadSettings = async () => {
    const settings = await getDefaults();
    setDefaults(settings);
    const result = await chrome.storage.local.get(["openaiApiKey"]);
    if (result.openaiApiKey) {
      setOpenaiApiKey(result.openaiApiKey);
    }
  };
  const checkConnectionStatus = async () => {
    try {
      const googleToken = await chrome.identity.getAuthToken({ interactive: false });
      setGoogleConnected(!!googleToken.token);
    } catch {
      setGoogleConnected(false);
    }
    const storage = await chrome.storage.local.get(["outlookToken", "outlookConnected"]);
    setOutlookConnected(!!storage.outlookToken || !!storage.outlookConnected);
  };
  const handleSave = async () => {
    setSaving(true);
    setMessage("");
    try {
      await saveDefaults(defaults);
      if (openaiApiKey.trim()) {
        await chrome.storage.local.set({ openaiApiKey: openaiApiKey.trim() });
      }
      setMessage("Settings saved successfully!");
      setTimeout(() => setMessage(""), 3e3);
    } catch (error) {
      setMessage("Error saving settings");
      console.error(error);
    } finally {
      setSaving(false);
    }
  };
  const handleConnectGoogle = async () => {
    try {
      const token = await chrome.identity.getAuthToken({ interactive: true });
      if (token.token) {
        setGoogleConnected(true);
        await chrome.storage.local.set({ googleConnected: true });
        setMessage("Google Calendar connected!");
        setTimeout(() => setMessage(""), 3e3);
      }
    } catch (error) {
      console.error("Google auth error:", error);
      setMessage("Failed to connect Google Calendar");
    }
  };
  const handleDisconnectGoogle = async () => {
    try {
      const token = await chrome.identity.getAuthToken({ interactive: false });
      if (token.token) {
        await chrome.identity.removeCachedAuthToken({ token: token.token });
      }
      await chrome.storage.local.remove("googleConnected");
      setGoogleConnected(false);
      setMessage("Google Calendar disconnected");
      setTimeout(() => setMessage(""), 3e3);
    } catch (error) {
      console.error("Error disconnecting Google:", error);
    }
  };
  const handleConnectOutlook = async () => {
    try {
      const clientId = "ca0fddd7-53ce-4f46-8a7d-4bab1f70ced0";
      const redirectUri = chrome.identity.getRedirectURL();
      const scope = "https://graph.microsoft.com/Calendars.ReadWrite offline_access";
      console.log("Starting Outlook auth...");
      console.log("Extension ID:", chrome.runtime.id);
      console.log("Redirect URI:", redirectUri);
      const generateRandomString = (length) => {
        const array = new Uint8Array(length);
        crypto.getRandomValues(array);
        return Array.from(array, (byte) => byte.toString(16).padStart(2, "0")).join("").substring(0, length);
      };
      const sha256 = async (plain) => {
        const encoder = new TextEncoder();
        const data = encoder.encode(plain);
        return await crypto.subtle.digest("SHA-256", data);
      };
      const base64urlencode = (buffer) => {
        const bytes = new Uint8Array(buffer);
        let binary = "";
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
      };
      const codeVerifier = generateRandomString(128);
      const hashed = await sha256(codeVerifier);
      const codeChallenge = base64urlencode(hashed);
      await chrome.storage.local.set({ outlookCodeVerifier: codeVerifier });
      const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=${clientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(scope)}&response_mode=query&prompt=select_account&code_challenge=${codeChallenge}&code_challenge_method=S256`;
      console.log("Auth URL:", authUrl);
      const responseUrl = await chrome.identity.launchWebAuthFlow({
        url: authUrl,
        interactive: true
      });
      console.log("Response URL:", responseUrl);
      if (!responseUrl) {
        throw new Error("No response from authentication");
      }
      const urlObj = new URL(responseUrl);
      console.log("Parsed URL params:", Object.fromEntries(urlObj.searchParams));
      const code = urlObj.searchParams.get("code");
      const error = urlObj.searchParams.get("error");
      const errorDescription = urlObj.searchParams.get("error_description");
      if (error) {
        throw new Error(`Auth error: ${error} - ${errorDescription || "Unknown error"}`);
      }
      if (!code) {
        console.error("No code in response URL. Full URL:", responseUrl);
        throw new Error("No authorization code received. Check Azure redirect URI configuration.");
      }
      const { outlookCodeVerifier } = await chrome.storage.local.get("outlookCodeVerifier");
      if (!outlookCodeVerifier) {
        throw new Error("Code verifier not found. Please try again.");
      }
      const tokenResponse = await fetch("https://login.microsoftonline.com/common/oauth2/v2.0/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: clientId,
          scope,
          code,
          redirect_uri: redirectUri,
          grant_type: "authorization_code",
          code_verifier: outlookCodeVerifier
        })
      });
      if (!tokenResponse.ok) {
        const error2 = await tokenResponse.json();
        throw new Error(error2.error_description || "Token exchange failed");
      }
      const tokens = await tokenResponse.json();
      await chrome.storage.local.set({
        outlookToken: tokens.access_token,
        outlookRefreshToken: tokens.refresh_token,
        outlookTokenExpiry: Date.now() + tokens.expires_in * 1e3,
        outlookConnected: true
      });
      await chrome.storage.local.remove("outlookCodeVerifier");
      setOutlookConnected(true);
      setMessage("Outlook Calendar connected with auto-refresh!");
      setTimeout(() => setMessage(""), 3e3);
    } catch (error) {
      console.error("Outlook auth error:", error);
      setMessage(`Failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  };
  const handleDisconnectOutlook = async () => {
    try {
      await chrome.storage.local.remove([
        "outlookToken",
        "outlookRefreshToken",
        "outlookTokenExpiry",
        "outlookConnected"
      ]);
      setOutlookConnected(false);
      setMessage("Outlook Calendar disconnected");
      setTimeout(() => setMessage(""), 3e3);
    } catch (error) {
      console.error("Error disconnecting Outlook:", error);
    }
  };
  const currentTz = getTimezone(defaults.tzOverride);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl mx-auto p-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-bold text-gray-900 mb-2", children: "Chronos Settings" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-600", children: "Manage your calendar connections and default settings" })
    ] }),
    message && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6 p-4 bg-green-50 border border-green-200 text-green-800 rounded-lg", children: message }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-semibold mb-4", children: "Calendar Accounts" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6 pb-6 border-b border-gray-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logos/google-calendar.jpg", alt: "Google Calendar", className: "w-full h-full object-cover" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-gray-900", children: "Google Calendar" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600", children: googleConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-600", children: "✓ Connected" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-500", children: "Not connected" }) })
          ] })
        ] }),
        googleConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleDisconnectGoogle, className: "btn-secondary", children: "Disconnect" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleConnectGoogle, className: "btn-primary", children: "Connect" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center bg-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "/logos/outlook-calendar.png", alt: "Outlook Calendar", className: "w-full h-full object-cover" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-gray-900", children: "Outlook Calendar" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600", children: outlookConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-600", children: "✓ Connected" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-500", children: "Not connected" }) })
            ] })
          ] }),
          outlookConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleDisconnectOutlook, className: "btn-secondary", children: "Disconnect" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleConnectOutlook, className: "btn-primary", children: "Connect" })
        ] }),
        !outlookConnected && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 p-3 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium mb-1", children: "⚠️ Setup Required" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "You need to configure your Microsoft Client ID in the manifest.json file and in OptionsApp.tsx before connecting Outlook." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-semibold mb-4", children: "API Configuration" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "openaiApiKey", className: "block text-sm font-medium text-gray-700 mb-2", children: "OpenAI API Key (Optional)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              id: "openaiApiKey",
              type: showApiKey ? "text" : "password",
              value: openaiApiKey,
              onChange: (e) => setOpenaiApiKey(e.target.value),
              placeholder: "sk-proj-...",
              className: "input w-full pr-24"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setShowApiKey(!showApiKey),
              className: "absolute right-2 top-1/2 -translate-y-1/2 text-sm text-gray-600 hover:text-gray-900 px-2 py-1",
              children: showApiKey ? "Hide" : "Show"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-gray-500 mt-1", children: [
          "Used for advanced natural language parsing. Get your key at",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://platform.openai.com/api-keys", target: "_blank", rel: "noopener noreferrer", className: "text-purple-600 hover:underline", children: "platform.openai.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 mt-1", children: "🔒 Your API key is stored locally and never leaves your device" })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "card mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-semibold mb-4", children: "Default Settings" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "duration", className: "block text-sm font-medium text-gray-700 mb-2", children: "Default Event Duration" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              id: "duration",
              value: defaults.durationMinutes,
              onChange: (e) => setDefaults({ ...defaults, durationMinutes: parseInt(e.target.value) }),
              className: "input max-w-xs",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "15", children: "15 minutes" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "30", children: "30 minutes" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "45", children: "45 minutes" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "60", children: "1 hour" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "90", children: "1.5 hours" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "120", children: "2 hours" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500 mt-1", children: "Used when no duration is specified in your command" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Current Timezone" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-900 font-mono text-sm bg-gray-50 p-2 rounded border border-gray-200", children: currentTz }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500 mt-1", children: "Detected automatically from your browser" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleSave,
          disabled: saving,
          className: "btn-primary",
          children: saving ? "Saving..." : "Save Settings"
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "mt-8 text-center text-sm text-gray-500", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Chronos v1.0.1 • Built for fast multi-calendar scheduling" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs", children: "🔒 Your privacy matters: All calendar data stays on your device. We never collect or transmit your personal information." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-4 text-xs bg-gray-100 p-2 rounded font-mono", children: [
        "Extension ID: ",
        chrome.runtime.id
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-gray-400", children: "ℹ️ Copy this ID if you need to configure OAuth in Google Cloud Console" })
    ] })
  ] });
}
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(OptionsApp, {}) })
);
//# sourceMappingURL=options.js.map
